---
title: Projects
date: 2021-04-02 22:42:03
---

Below are some of the little projects that I've done over the last few years:

### 1. News Generator - Get your preferred news at a click.
Key Concepts: JavaScript, Google App Script, News API
Relevant Tutorials:
* [Google - Analyze the sentiment of news headlines](https://developers.google.com/workspace/solutions/news-sentiment)
* [News API](https://newsapi.org/)

<img src="images\NewsAlert.png" width=40% height=60% style="display:inline">