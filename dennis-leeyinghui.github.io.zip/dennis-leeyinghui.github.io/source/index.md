---
title: About
date: 2021-04-02 22:41:05
---

## A current Graduate student of Island Studies in Canada. <br><br> Open to all challenges.

| <ul style="font-size:25px; line-height:50px; font-weight: 500; padding-left: 10%;"><li style="width:80%">Innovator</li><li>Hobby Graphic Designer</li><li>Self-taught Frontend Developer</li></ul>| <img src="images\graphic.png" width=50% height=50% style="text-align: center"> |
|-------------------------------------------------------------------------|----------------------------------------------------------------------------|

#Tech #Tourism #Research 
#NewBusinessModel #DigitalTransformation

Contact:　 [Email](mailto:drl0jermb@relay.firefox.com)　[LinkedIn](https://www.linkedin.com/in/dennis-lee-7984951b8/)

