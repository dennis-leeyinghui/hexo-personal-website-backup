---
title: Becoming New Parents
date: 2021-04-02 21:23:24
tags:
---

My wife and I are expecting our newborn in two months. Nothing is more exciting than the fact that you are going to meet the cutest person in the world very soon.


However, it is undeniable that heavy financial stress could strike much earlier that the little baby arrives. 


I've gathered some tips from myself and online communities on some frugal ways to welcome your babies:

