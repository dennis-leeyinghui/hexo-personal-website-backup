---
title: Thoughts
date: 2021-04-05 15:04:02
---