---
title: Hello World!
date: 2021-04-02 21:17:06
tags:
---

I'm very excited to learn more about Javascript every day. My short-term goal would be becoming a frontend developer.

The future for Javascript is very bright, thanks to its simplicity and popularity.

There are a few Javascript libraries that really surprise me:
* [Threejs: 3D library](https://threejs.org/)
* [D3: Visualize data](https://d3js.org/)
* [Chartjs: Create animated charts](https://www.chartjs.org/)
