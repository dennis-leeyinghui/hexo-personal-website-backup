A Pen created at CodePen.io. You can find this one at http://codepen.io/dennis-leeyinghui/pen/qjRpjQ.

 A Simple Shopping List and Inventory built with AngularJS 