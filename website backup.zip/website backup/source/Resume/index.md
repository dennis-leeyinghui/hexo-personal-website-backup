---
title: Resume
date: 2021-04-02 23:20:18
---

* * *

#### Awards
UPEI Entrance Scholarships (CA$5,000)  
UPEI Student Adversity Award (CA$1,000)  
Hong Kong Commercial Radio 50th Anniversary Scholarship (HK$20,000)

* * *

#### Research
(2020) Public Sector - Analysis of Electric Vehicles Charging Points 
(2020) Public Sector - Reducing Organizational Red Tape

* * *

#### Education
**Island Studies [Master's]**  
University of Prince Edward Island (UPEI)  
Canada | 2020-2021

**International Journalism [Bachelor's]**  
Hong Kong Baptist University (HKBU)  
Hong Kong | 2010-2013