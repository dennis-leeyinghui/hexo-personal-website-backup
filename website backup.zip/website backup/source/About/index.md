---
title: About
date: 2021-04-02 22:41:05
---

## A current Graduate student of Island Studies in Canada. <br><br> Open to all challenges.

* Innovator
* Hobby Graphic Designer
* Self-taught Frontend Developer

#Tech #Tourism #Research #NewBusinessModel #DigitalTransformation


