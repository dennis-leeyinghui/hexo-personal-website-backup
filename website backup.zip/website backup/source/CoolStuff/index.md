---
title: Cool Stuff
date: 2021-04-02 22:41:59
---

* * *
#### Tools

* [Generated Photos - AI-generated photos for different use cases](https://generated.photos/use-cases)
* [Lobe - Free machine learning training model](https://lobe.ai/examples)
* [PDF Mage - HTML to PDF converter](https://pdfmage.org/)
* [DocRaptor - HTML-to-PDF, HTML-to-Excel generator](https://docraptor.com/try_it_out)
* [Newsfilter - Powerful real-time news gatherer and email alerts](https://newsfilter.io/)
* [News API - News API Data Feed](https://newsapi.org/)
* [Straightaway - Route optimizer for multiple industries (e.g. courier, real estate...)](https://www.getstraightaway.com/features)
* []()

* * *

#### Open Source
* [DokuWiki - Wiki software](https://www.dokuwiki.org/dokuwiki)
* [Wiki.js - Wiki software](https://js.wiki/)
* [Awesome Open Source - Open source projects database](https://awesomeopensource.com/)
* [Flarum - Community management](https://flarum.org/)
* [Discourse - Community management](https://www.discourse.org/)
* [BookStack - Knowledge management platform](https://www.bookstackapp.com/)
* [Gitter - Live chatroom & community](https://gitter.im/)
* [Flatboard - Community management](https://flatboard.org/index.php/forum/)
* [Vanilla Forums - Community management](https://vanillaforums.com/en/showcase/)
* [Codoforum - Community management](https://codoforum.com/documentation/introduction)
* [NodeBB - Community management](https://community.nodebb.org/topic/180/who-is-using-nodebb)
* [Museo - Search art collections of world's museums.](https://museo.app/?q=)
* [SandDance - Visualize qualitative data](https://microsoft.github.io/SandDance/app/)
* [SuperTokens - Free alternative to Auth0, Firebase Auth and AWS Cognito](https://supertokens.io/)
* [ICONS8 - Free icons](https://icons8.com/)
* [hitobito - Membership & association administration](https://hitobito.com/en)
* []()

* * *

#### Online Collaboration
* [Typeform - Less boring surveys](https://www.typeform.com/)
* [Google Jamboard - Online Whiteboard](https://jamboard.google.com/)
* [Miro - Online Whiteboard](https://miro.com/)
* [Mentimeter - Collaborative Tag Cloud](https://www.menti.com/)
* []()

* * *

#### E-Commerce
* [Gumroad - Simple Online Store](https://gumroad.com/)
* []()

* * *

#### Cool Concepts
* [Neo-Generalist - a restless multi-disciplinarian](https://www.forbes.com/sites/danpontefract/2017/02/15/dont-be-afraid-to-call-yourself-a-neo-generalist/?sh=51eb69913b08)
* [Human-Centered Design - involve your users early](https://www.wired.com/insights/2013/12/human-centered-design-matters/)

* * *

#### Parenting / Education
* [Family Man - Free parenting courses for dads.](https://familyman.movember.com/)
* []()

* * *
#### Education

* []()


